package utils;

import controllers.SettingsController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Util {

    public Stage openStage( String xmlName ) throws IOException {
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource(xmlName));

        /*
        FXMLLoader fxmlLoader = new FXMLLoader();
        Object object = fxmlLoader.getController();
        if ( object instanceof SettingsController ) {
            SettingsController obj = (SettingsController) object;
            //..
        }
        */

        Scene scene = new Scene(parent);
        stage.setScene(scene);
        return stage;
    }

}
