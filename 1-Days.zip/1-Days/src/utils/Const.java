package utils;

public class Const {

    public static  String settings = "/views/settings.fxml";

}
