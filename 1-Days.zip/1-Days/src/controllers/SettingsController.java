package controllers;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class SettingsController implements Initializable {

    public void initVariable(String name){
        lblName.setText(name);
    }

    @FXML
    Label lblName;

    public String name = "";
    public SettingsController() {
        System.out.println("name : " + name);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblName.setText(name);
    }


}
