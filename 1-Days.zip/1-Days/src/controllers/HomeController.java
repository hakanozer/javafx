package controllers;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import utils.Const;
import utils.Util;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HomeController implements Initializable {

    Util util = new Util();

    @FXML
    Label lblName;


    public HomeController() {
        System.out.println("Controller Call");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblName.setText("Hello FX");
        System.out.println("initialize call");
    }


    @FXML
    public void btnCall(ActionEvent event) throws IOException {
        //SettingsController.name = "Btn Call Action";
        Stage stage = util.openStage(Const.settings);
        stage.setTitle("Title Page");
        stage.show();
        //util.openStage(Const.settings).show();
    }


    @FXML
    public void btnCall2(ActionEvent event) throws IOException {

        try {

            Stage st = new Stage();
            FXMLLoader loader = new FXMLLoader(getClass().getResource(Const.settings));
            Parent sceneMain = loader.load();
            SettingsController controller = loader.getController();
            controller.initVariable("Hello JavaFX ");
            Scene scene = new Scene(sceneMain);
            st.setScene(scene);
            st.show();

        } catch (IOException ex) {
        }



    }


}
